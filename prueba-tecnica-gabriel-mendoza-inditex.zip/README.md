# React + Vite

PRUEBA TÉCNICA GABRIEL MENDOZA APTYCREA


He desarrollado la prueba utilizando React + JavaScript y compilé la aplicación con Vite5.

//--
Hubiese quizás podido usar la bilbioteca React Router Dom + API URLSearchParams de JavaScript para la obtención de datos a través de la URL (GETS), obteniendo esos datos podría haber aplicado un filter para mostrar solamento los productos requeridos. Al trabajar con datos mockeados no lo vi necesario de implementar.
--//

Para la maquetación, usé la metodología BEM junto con el preprocesador SASS para mejorar la estructura del código CSS, facilitando la escritura del código CSS, buscando  optimizar el diseño y la alineación de elementos en la página web.

He utilizado diversas bibliotecas para crear una interfaz de usuario interactiva y dinámica:

Se está implementó la funcionalidad de arrastrar y soltar utilizando la biblioteca @dnd-kit/core. Usé funciones de orden superior como SortableContext y DndContext, para envolver componentes y proporcionarles funcionalidades específicas.

He usado un patrón de diseño standard, para los componentes, he dividido la interfaz de usuario en partes más pequeñas y manejables, lo que facilita el mantenimiento y la reutilización del código, para la interfaz tenemos los componentes "RowItems" "ListItems" e "Itemproduct" , luego me he apoyado en "Material UI" para la creación de componentes de utilidad como por ejemplo botones, iconos.

Opté por la utilización de componentes funcionales y sus distintos hooks para el manejo de estados, consumir o enviar datos a endpoints (para esta prueba obviamente los he mockeado) y los efectos secundarios en los componentes funcionales de React.

Para la creación de "Rows" e "Ítems" en todo momento he construido y actualizado objetos almacenados en un estado local, los cuales he pasado a través de props para gestionar toda la lógica de construcción de la "Parrilla" con el manejo de index de cada elemento.

Para la función zoomIn zoomOut, establecí un máximo y un mínimo, además que me apoyé en transiciones de css para suavizar el efecto.

Hice un pequeño efecto de entrada de elementos que aprovecha la propiedad transform del elemento.

La estructura de carpeta usada:

- src /
    - main.js
    - App.js
    - index.css (minificado)
    - index.scss
        - assets /
            - scss /
                _parrilla.scss
                _presets.scss
        - components / 
            - animation /
                - RevealBoxes.js
            - utils /
                - Button.jsx
                - IconButton.jsx
            - ItemProduct.jsx // Listado de "Items" para ser añadidos
            - ListItems.jsx // Gestiona creación y renderización de "Items" 
            - RowItems.jsx  // Gestiona creación y renderización de "filas"      

NOTA:

Con algo más de tiempo podrían haberse mejorado muchas cosas, sin embargo he tratado de optimizar la APP lo mejor que he podido. Gracias por considerar mi perfil para este puesto, espero cumplir con las expectativas.
